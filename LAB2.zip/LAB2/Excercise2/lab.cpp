/*
 * lab.cpp
 *
 *  Created on: Sep 3, 2015
 *      Author: p_k29
 */


/*
 * file.cpp
 *
 *  Created on: Sep 3, 2015
 *      Author: p_k29
 */

#include<iostream>
#include<iomanip>
using namespace std;
int main()
{
	int a,b,quotient;
	int count=0;
	cout<<"Please enter two integers greater than 0:";
	cin>>a>>b;
	if(a>0 && b>0)
	{
		while(a>b)
	   {
		quotient=a-b;
		count++;
		a=quotient;
	   }
	cout<<"Remainder ="<<quotient;
	cout<<"Quotient="<<count;
	}
	else
		cout<<"Error, both numbers must be greater than 0";

	return 0;

}



