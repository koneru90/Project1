/*
 * new.cpp
 *
 *  Created on: Sep 3, 2015
 *      Author: p_k29
 */


/*
 * lab.cpp
 *
 *  Created on: Sep 3, 2015
 *      Author: p_k29
 */

#include<iostream>
#include<iomanip>
using namespace std;
int main()
{
	cout<<setprecision(1)<<fixed;
	int num,m1,m2,m3;
	double avg,fastest,tem=9999;
	string name;
	cout<<"Please enter the number of rats in the experiment:";
	cin>>num;

	for(int i=1;i<=num;i++)
	{
		cout<<"\nPlease enter the rats name and three maze times:";
		cin>>name>>m1>>m2>>m3;
		avg=(m1+m2+m3)/3.0;
		cout<<name <<" "<<"average time:"<<avg;

        if(avg<tem)
			tem=avg;
	}

	cout<<"\nThe fastest average time was:"<<tem;

	return 0;

}





