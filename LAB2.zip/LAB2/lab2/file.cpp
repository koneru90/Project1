/*
 * file.cpp
 *
 *  Created on: Sep 3, 2015
 *      Author: p_k29
 */

#include<iostream>
#include<iomanip>
using namespace std;
int main()
{
	float wt,dist,charges;
	cout<<setprecision(2)<<fixed;
	cout<<"Please enter the weight of the package in pounds:";
	cin>>wt;
	cout<<"Please enter the distance to be shipped in miles:";
	cin>>dist;

	if((wt<0||wt>100)||(dist<10||dist>3000))
	{
		cout<<"That is an invalid weight or distance";
		cin>>wt>>dist;
	}
	else
	{
		if(wt<=10)
		{
			charges=9.99*dist/500.0;
			cout<<"The cost for shipping is:"<<charges<<endl;
		}
		else if(wt>10&&wt<=30)
		{
		charges=14.99*dist/500.0;
		cout<<"The cost for shipping is:"<<charges<<endl;
		}
		if(wt>30&&wt<=50)
		{
		charges=19.99*dist/500.0;
		cout<<"The cost for shipping is:"<<charges<<endl;
		}
		if(wt>50&&wt<=100)
		{
		charges=24.99*dist/500.0;
		cout<<"The cost for shipping is:"<<charges<<endl;
		}

	}
	return 0;



}

